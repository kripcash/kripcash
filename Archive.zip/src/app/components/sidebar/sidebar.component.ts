import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../../services/authentication.service'; 
import { Storage } from '@ionic/storage'; 

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss'],
})
export class SidebarComponent implements OnInit {
public url1: string = "";
 
email: string = "";
address:any;
city:any;
state:any;
zip:any;

data: any;
user:any;
rate:any;

anggota:any;
krip_email:any;
krip_user:any;
user_ip: any;
balance: any;
phone_code: any;
fullname:any;
currency:any;
user_state:any;
user_city:any;
country:any;
ex_rate:any; 

  constructor(private router: Router,private AuthService: AuthenticationService, private storage: Storage) { }

   ionViewWillEnter(){
    this.storage.get('session_storage').then((res)=>{
      this.anggota = res;
        this.krip_email = this.anggota.krip_email;
        this.krip_user = this.anggota.krip_user;
        this.user_ip = this.anggota.user_ip;
        this.balance = this.anggota.balance;
        this.phone_code = this.anggota.phone_code;
        this.fullname = this.anggota.fullname;
        this.currency = this.anggota.currency;
        this.user_state = this.anggota.user_state;
        this.user_city = this.anggota.user_city;
        this.country = this.anggota.country;
        this.ex_rate = this.anggota.ex_rate;
        this.rate = this.anggota.rate
        console.log(res);
        console.log(this.krip_email);

  });
  
  }
   dashboardPage()
  {
  this.router.navigate(['dashboard']);
  }
  ticketsPage()
  {
  this.router.navigate(['ticket']);
  }
  historyPage()
  {
  this.router.navigate(['history']);
  }
  settingsPage()
  {
  this.router.navigate(['settings']);
  }
  profilePage()
  {
  this.router.navigate(['profile']);
  }
  logoutPage()
  {
	  this.AuthService.logout();
  }
  ngOnInit() {
	  
	 this.url1 = this.router.url;   
  }

}
