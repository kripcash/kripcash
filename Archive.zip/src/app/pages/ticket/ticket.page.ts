import { Component, OnInit, Renderer2, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { ModalController } from '@ionic/angular';
import { ToastController } from '@ionic/angular';
import { PostProvider } from '../../providers/post-provider';
import { LoadingController } from '@ionic/angular';
import { AlertController } from '@ionic/angular';
import { AuthService } from '../../services/auth.service'; 
import { TicketService } from '../../services/ticket.service'; 
import { Storage } from '@ionic/storage'; 
import { CreateTicketPage } from '../create-ticket/create-ticket.page';

@Component({
  selector: 'app-ticket',
  templateUrl: './ticket.page.html',
  styleUrls: ['./ticket.page.scss'],
})
export class TicketPage implements OnInit {

  [x: string]: any;

  email: string = "";
   address:any;
   city:any;
   state:any;
   zip:any;
   
   data: any;
   user:any;
   rate:any; 
 
   anggota:any;
   krip_email:any;
   krip_user:any;
   user_ip: any;
   balance: any;
   phone_code: any;
   fullname:any;
   currency:any;
   user_state:any;
   user_city:any;
   country:any;
   ex_rate:any; 
   sold_coin:any;
   bought_coin:any;
   ticketID:any;

  tickets: any=[];

  

   constructor(private modalController: ModalController, private router: Router, private render: Renderer2, public alertController: AlertController,
  	private postPvdr: PostProvider,
    public toastCtrl: ToastController,
    private ticketService: TicketService,
    private loadingCtrl: LoadingController,
    private storage: Storage,) { }


    async ionViewWillEnter(){

      const loading = await this.loadingCtrl.create({
        message: 'Please Wait...',
        spinner: "circular",
        duration: 3000
      });
      await loading.present();

      this.storage.get('session_storage').then((res)=>{
        this.anggota = res;
          this.krip_email = this.anggota.krip_email;
          this.krip_user = this.anggota.krip_user;
          this.user_ip = this.anggota.user_ip;
          this.balance = this.anggota.balance;
          this.phone_code = this.anggota.phone_code;
          this.fullname = this.anggota.fullname;
          this.currency = this.anggota.currency;
          this.user_state = this.anggota.user_state;
          this.user_city = this.anggota.user_city;
          this.country = this.anggota.country;
          this.ex_rate = this.anggota.ex_rate;
          this.rate = this.anggota.rate,
          this.sold_coin = this.anggota.sold_coin,
          this.bought_coin = this.anggota.bought_coin

          console.log(res);
          console.log(this.krip_email);
     
  
          let body = {
            kripUser : this.anggota.krip_email,
            aksi: 'ticketList'
          };
      
          this.postPvdr.postData(body, 'proses-api.php').subscribe(async data =>{
            var alertpesan = data.msg;
            if(data.success){
              this.tickets = data.result,
              this.tuser = this.tickets.ticketuser,
              this.ttype = data.result.tickettype,
              this.tmsg = data.result.ticketmsg,
              this.tid = data.result.ticketid,
              this.tstatus = data.result.status,
              this.tdate = data.result.date
              
      
              console.log(data);
              console.log(this.tickets);
              
            }else{
              
              console.log(data);
            }

      });
  
    });
    
    }

  async CreateTicket() {
    const modal = await this.modalController.create({
      component: CreateTicketPage
    });
    return await modal.present();
  }

  openTicket(item){
    this.ticketID = item;
    this.ticketService.setTicketData(item);
    this.router.navigate(['chat'])
    console.log(item);
  } 
 

  dashboardPage()
  {
	   this.router.navigate(['dashboard'])
  }
   notificationsPage()
  {
  this.router.navigate(['notifications'])
  }
  ngOnInit() {
    
  }

}
