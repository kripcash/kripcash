import { Component, OnInit, Renderer2, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { ModalController } from '@ionic/angular';
import { ToastController } from '@ionic/angular';
import { PostProvider } from '../../providers/post-provider';
import { LoadingController } from '@ionic/angular';
import { AlertController } from '@ionic/angular';
import { TransactService } from '../../services/transact.service'; 
import { AuthService } from '../../services/auth.service'; 
import { Storage } from '@ionic/storage'; 
import { BankaccountService } from '../../services/bankaccount.service'; 
import { Clipboard } from '@ionic-native/clipboard/ngx';

@Component({
  selector: 'app-payments',
  templateUrl: './payments.page.html',
  styleUrls: ['./payments.page.scss'],
})
export class PaymentsPage implements OnInit {
  [x: string]: any;

  datas:any;
  address:any;
  anggota: any;
  krip_email: any;
  krip_user: any;
  transactUser: any;
  user_bank: any;
  krip_payment: any;
  code: any;
  priceT: any;
  priceBTC: any;
  status: any;
  transactID: any;
  ip: any;
  date: any;
  rate: any;


  transactImg:string = "";
  transactTitle:string = "";
  transactStatus:string = "";
  transactColor:string = "";

  payImg:string = "";
  payTitle:string = "";
  payStatus:string = "";
  payColor:string = "";

  

  constructor(private modalController: ModalController, private router: Router, private render: Renderer2, public alertController: AlertController,
  	private postPvdr: PostProvider,
    private clipboard: Clipboard,
    public toastCtrl: ToastController,
    private loadingCtrl: LoadingController,
    private transactService: TransactService,
    private authService: AuthService,
    private bankService: BankaccountService,
    private storage: Storage,) { 
      this.datas = this.transactService.getTransactData()
    }

ngOnInit() {
      this.address = this.datas.address;
    console.log(this.datas);
    console.log(this.address);
    }

   async refreshData(){

      const toast = await this.toastCtrl.create({
        message: 'Refreshing...',
        duration: 3000
      });
      toast.present();


      let body = {
        transactID : this.datas,
        aksi: 'transactOpen'
      };
  
      this.postPvdr.postData(body, 'proses-api.php').subscribe(async data =>{
        var alertpesan = data.msg;
        if(data.success){
          this.transactService.setTransactData(this.datas);
          this.datas = this.transactService.getTransactData();
          this.stateDat = data.result.payment;
          this.transactUser = data.result.krip_user,
          this.address = data.result.address,
          this.user_bank = data.result.user_bank,
          this.krip_payment = data.result.krip_payment,
          this.code = data.result.code,
          this.priceT = data.result.price,
          this.priceBTC = data.result.pricebtc,
          this.status = data.result.status,
          this.transactID = data.result.product,
          this.ip = data.result.ip,
          this.date = data.result.date,

          console.log(data.result);
          console.log(this.priceBTC);
          
        }else{
          const toast = await this.toastCtrl.create({
            message: 'Transaction Invalid',
            duration: 3000
          });
          toast.present();
          console.log(data);
        }

        if(this.status=='-1'){
          this.transactImg="../../../assets/images/loading.gif";
          this.transactTitle="Waiting For Bitcoin";
          this.transactStatus="Pending";
          this.transactColor="warning";
  
        }else{
          this.transactImg="../../../assets/images/check.png";
          this.transactTitle="Bitcoin Received";
          this.transactStatus="Paid";
          this.transactColor="success";
        }

        if(this.krip_payment=='Unpaid'){
          this.payImg="../../../assets/images/loading.gif";
          this.payTitle="Funding Account";
          this.payStatus="Pending";
          this.payColor="warning";
  
        }else{
          this.payImg="../../../assets/images/check.png";
          this.payTitle="Account Funded";
          this.payStatus="Funded";
          this.payColor="success";
        }

        });
  
    }

    doRefresh(event) {
      this.refreshData(); 
      console.log('Refreshing..');

  
      setTimeout(() => {
       
        event.target.complete();
      }, 2000);
    }

    
    
    async ionViewWillEnter(){
      
      
      if(this.datas==""){
        this.router.navigate(['dashboard']) 
        const toast = await this.toastCtrl.create({
          message: 'Transaction Invalid',
          duration: 3000
        });
      }


     
      
      
      const loading = await this.loadingCtrl.create({
        message: '',
        spinner: "circular",
        duration: 1000
      });

      await loading.present();
  
      this.storage.get('session_storage').then((res)=>{
        this.anggota = res;
          this.krip_email = this.anggota.krip_email;
          this.krip_user = this.anggota.krip_user;
          this.rate = this.anggota.rate;
          
  
          console.log(res);
          console.log(this.krip_email);

          
     
  
      let body = {
        transactID : this.datas,
        aksi: 'transactOpen'
      };
  
      this.postPvdr.postData(body, 'proses-api.php').subscribe(async data =>{
        var alertpesan = data.msg;
        if(data.success){
          this.transactService.setTransactData(this.datas);
          this.stateDat = data.result.payment;
          this.transactUser = data.result.krip_user,
          this.address = data.result.address,
          this.user_bank = data.result.user_bank,
          this.krip_payment = data.result.krip_payment,
          this.code = data.result.code,
          this.priceT = data.result.price,
          this.priceBTC = data.result.pricebtc,
          this.status = data.result.status,
          this.transactID = data.result.product,
          this.ip = data.result.ip,
          this.date = data.result.date,

          console.log(data.result);
          
        }else{
          const toast = await this.toastCtrl.create({
            message: 'Transaction Invalid',
            duration: 3000
          });
          toast.present();
          console.log(data);
        }

        if(this.status=='-1'){
          this.transactImg="../../../assets/images/loading.gif";
          this.transactTitle="Waiting For Bitcoin";
          this.transactStatus="Pending";
          this.transactColor="warning";
  
        }else if(this.status=='-2'){
          this.transactImg="../../../assets/images/loading.gif";
          this.transactTitle="Waiting For Bitcoin";
          this.transactStatus="Uncomplete";
          this.transactColor="warning";
  
        }else{
          this.transactImg="../../../assets/images/check.png";
          this.transactTitle="Bitcoin Received";
          this.transactStatus="Paid";
          this.transactColor="success";
        }

        if(this.krip_payment=='Unpaid'){
          this.payImg="../../../assets/images/loading.gif";
          this.payTitle="Funding Account";
          this.payStatus="Pending";
          this.payColor="warning";
  
        }else{
          this.payImg="../../../assets/images/check.png";
          this.payTitle="Account Funded";
          this.payStatus="Funded";
          this.payColor="success";
        }
        
      });
  
    });

   

    let timer = setInterval(()=> {
      
      this.refreshData(); 
      
    }, 30000); 
  
    clearInterval(timer);

    }

    async refreshPage(){
      const loading = await this.loadingCtrl.create({
      
        spinner: "circular",
        duration: 2000
      });
      await loading.present();

      this.refreshData(); 
    }

    


  copyClipboard(){
    this.clipboard.copy(this.address);
  }
  homePage(){

    let timer = clearInterval();

    this.router.navigate(['dashboard']);
    
    clearInterval();
    
  }

  dashboardPage()
  {
   this.router.navigate(['dashboard'])
  }
   notificationsPage()
  {
  this.router.navigate(['notifications'])
  }
  profilePage()
  {
	  this.router.navigate(['profile'])
  }
  

}
