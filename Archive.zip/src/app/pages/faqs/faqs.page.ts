import { Component, OnInit, Renderer2} from '@angular/core';
import { Router } from '@angular/router';
import { ModalController } from '@ionic/angular';
import { ToastController } from '@ionic/angular';
import { PostProvider } from '../../providers/post-provider';
import { LoadingController } from '@ionic/angular';
import { AlertController } from '@ionic/angular';
import { UsernameService } from '../../services/username.service'; 
import { AuthService } from '../../services/auth.service';
import { Storage } from '@ionic/storage'; 
import { TransactService } from '../../services/transact.service'; 

@Component({
  selector: 'app-faqs',
  templateUrl: './faqs.page.html',
  styleUrls: ['./faqs.page.scss'],
})
export class FaqsPage implements OnInit {

  email: string = "";
  address:any;
  city:any;
  state:any;
  zip:any;
  
  data: any;
  user:any;
  rate:any;

  anggota:any;
  krip_email:any;
  krip_user:any;
  user_ip: any;
  balance: any;
  phone_code: any;
  fname:any;
  lname:any;
  currency:any;
  user_state:any;
  user_city:any;
  country:any;
  ex_rate:any; 
  
  
 public menustatus: any;
 faqs: any=[];
 price: any;
 date: any;
 transactID: any;
 transID: any;
 product: any;
 krip_payment: any;
  
 constructor(private modalController: ModalController, private router: Router, private render: Renderer2, public alertController: AlertController,
  private postPvdr: PostProvider,
  public toastCtrl: ToastController,
  private loadingCtrl: LoadingController,
  private storage: Storage,) { }

  dashboardPage()
  {
   this.router.navigate(['dashboard'])
  }
  async ionViewWillEnter(){
    const loading = await this.loadingCtrl.create({
      
      spinner: "circular",
      duration: 2000
    });
    await loading.present();

    this.storage.get('session_storage').then((res)=>{
      this.anggota = res;
        this.krip_email = this.anggota.krip_email;
        this.krip_user = this.anggota.krip_user;
        this.user_ip = this.anggota.user_ip;
        this.balance = this.anggota.balance;
        this.phone_code = this.anggota.phone_code;
        this.fname = this.anggota.fname;
        this.lname = this.anggota.lname;
        this.currency = this.anggota.currency;
        this.user_state = this.anggota.user_state;
        this.user_city = this.anggota.user_city;
        this.country = this.anggota.country;
        this.ex_rate = this.anggota.ex_rate;
        this.rate = this.anggota.rate
        console.log(res);
        console.log(this.krip_email);
   

    let body = {
      aksi: 'getFaq'
    };

    this.postPvdr.postData(body, 'proses-api.php').subscribe(async data =>{
      var alertpesan = data.msg;
      if(data.success){
        this.faqs = data.result,

        console.log(data);
        console.log(this.faqs);
        
      }else{
        
        console.log(data);
      }
    });

  });
  
  }
  
   notificationsPage()
  {
  this.router.navigate(['notifications'])
  }
  settingsPage()
  {
	   this.router.navigate(['settings'])
  }
  profilePage()
  {
	  this.router.navigate(['profile'])
  }
  ngOnInit() {
  }

}
