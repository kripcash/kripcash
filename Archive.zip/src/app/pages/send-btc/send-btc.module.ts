import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { SendBtcPageRoutingModule } from './send-btc-routing.module';

import { SendBtcPage } from './send-btc.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    SendBtcPageRoutingModule
  ],
  declarations: [SendBtcPage]
})
export class SendBtcPageModule {}
