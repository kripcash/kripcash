import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SendBtcPage } from './send-btc.page';

const routes: Routes = [
  {
    path: '',
    component: SendBtcPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class SendBtcPageRoutingModule {}
