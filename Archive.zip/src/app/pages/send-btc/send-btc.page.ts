import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ModalController } from '@ionic/angular';
import { ToastController } from '@ionic/angular';
import { PostProvider } from '../../providers/post-provider';
import { LoadingController } from '@ionic/angular';
import { AlertController } from '@ionic/angular';
import { TransactService } from '../../services/transact.service'; 
import { AuthService } from '../../services/auth.service'; 
import { Storage } from '@ionic/storage'; 
import { BankaccountService } from '../../services/bankaccount.service'; 

@Component({
  selector: 'app-send-btc',
  templateUrl: './send-btc.page.html',
  styleUrls: ['./send-btc.page.scss'],
})
export class SendBtcPage implements OnInit {
  [x: string]: any;


  email: string = "";
  address:any;
  city:any;
  state:any;
  zip:any;
  
  data: any;
  user:any;

  anggota:any;
  krip_email:any;
  krip_user:any;
  user_ip: any;
  balance: any;
  phone_code: any;
  fullname:any;
  currency:any;
  user_state:any;
  user_city:any;
  country:any;
  ex_rate:any;

  pbtc: any = "";
  public pcash: any;
  bank_account:any;
  pbank: string = "";

  bankAcc : any;

  b_acc_bank_name:any;
  b_acc_acc_name:any;
  b_acc_acc_num:any;
  b_acc_id:any;

  exchange_rate:any;
  bitcoin_rate:any;
  
 



  constructor(private modalController: ModalController, private router: Router,  public alertController: AlertController,
  	private postPvdr: PostProvider,
    public toastCtrl: ToastController,
    private loadingCtrl: LoadingController,
    private transactService: TransactService,
    private authService: AuthService,
    private bankService: BankaccountService,
    private storage: Storage,) { }
  ngOnInit() {
  }

  async ionViewWillEnter(){
    const loading = await this.loadingCtrl.create({
      message: 'Please Wait...',
      spinner: "circular",
      duration: 1000
    });
    await loading.present();

    this.storage.get('session_storage').then((res)=>{
      this.anggota = res;
        this.krip_email = this.anggota.krip_email;
        this.krip_user = this.anggota.krip_user;
        this.user_ip = this.anggota.user_ip;
        this.balance = this.anggota.balance;
        this.phone_code = this.anggota.phone_code;
        this.fullname = this.anggota.fullname;
        this.currency = this.anggota.currency;
        this.user_state = this.anggota.user_state;
        this.user_city = this.anggota.user_city;
        this.country = this.anggota.country;
        this.ex_rate = this.anggota.ex_rate;
        this.rate = this.anggota.rate,
        this.sold_coin = this.anggota.sold_coin,
        this.bought_coin = this.anggota.bought_coin

        console.log(res);
        console.log(this.krip_email);
   

    let body = {
      kripemail : this.anggota.krip_email,
      aksi: 'bankacc'
    };

    this.postPvdr.postData(body, 'proses-api.php').subscribe(async data =>{
      var alertpesan = data.msg;
      if(data.success){
        this.bankService.setBankData(data.result);
        this.datBank = data.success;
        this.b_acc_bank_name = data.result.b_acc_bank_name;
        this.b_acc_acc_name = data.result.b_acc_acc_name;
        this.b_acc_acc_num = data.result.b_acc_acc_num;
        this.b_acc_id = data.result.id;

        console.log(data.result);
        
      }else{
        const toast = await this.toastCtrl.create({
          message: 'Add bank account to receive funds',
          duration: 3000
        });
        toast.present();
        console.log(data);
      }
    });

    let bod = {
      aksi: 'getrate'
    };

    this.postPvdr.postData(bod, 'proses-api.php').subscribe(async data =>{
      var alertpesan = data.msg;
      if(data.success){
        this.rates = data.success,
        this.exchange_rate = data.result.exchange_rate,
        this.bitcoin_rate = data.result.bitcoin_rate,
        

        console.log(data);
        console.log(this.transacts);
        
      }else{
        this.trans = data.transact
        
        console.log(data);
      }
    });

  });


  }

 
  closeModal(){
    this.modalController.dismiss();
  }

  addBank(){
    this.router.navigate(['profile']); 
    this.modalController.dismiss();
  }

  async sellBtc(){

    if(this.pbtc==""){
      const toast = await this.toastCtrl.create({
        message: 'Amount is required',
        duration: 3000
      });
      toast.present();
  }else if(this.pbank==""){
      const toast = await this.toastCtrl.create({
        message: 'Select bank to continue',
        duration: 3000
      });
      toast.present();
  }else{

    const loading = await this.loadingCtrl.create({
      message: 'Loading...',
      spinner: "circular"
    });
    await loading.present();

    let body = {
      kripemail : this.anggota.krip_email,
      pbank: this.pbank,
      pbtc: this.pbtc,
      rate: this.ex_rate,
      pcash: this.pcash,
      aksi: 'sellbitcoin'
    };

    this.postPvdr.postData(body, 'proses-api.php').subscribe(async data =>{
      var alertpesan = data.msg;
      if(data.success){
        this.transactService.setTransactData(data.result.product);
        this.datBank = data.success;
        
this.router.navigate(['payments']);
  this.modalController.dismiss();
        console.log(data.result);
        this.loadingCtrl.dismiss();
        
      }else{
        const toast = await this.toastCtrl.create({
          message: alertpesan,
          duration: 3000
        });
        toast.present();
        console.log(data);
      }
    });
  
 
  
  }
}


}
