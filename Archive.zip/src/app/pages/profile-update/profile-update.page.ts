import { Component, OnInit, Renderer2 } from '@angular/core';
import { ToastController } from '@ionic/angular';
import { PostProvider } from '../../providers/post-provider';
import { Router } from '@angular/router';
import { LoadingController } from '@ionic/angular';
import { AlertController } from '@ionic/angular';
import { UsernameService } from '../../services/username.service'; 
import { AuthService } from '../../services/auth.service'; 
import { Storage } from '@ionic/storage'; 
import { BehaviorSubject } from 'rxjs';

@Component({
  selector: 'app-profile-update',
  templateUrl: './profile-update.page.html',
  styleUrls: ['./profile-update.page.scss'],
})
export class ProfileUpdatePage implements OnInit {

  authState = new BehaviorSubject(false);

  private loading;

  email: string = "";
  phone:any;
  name:any;
  pass:any;
  
  data: any;
  user:any;

  constructor(private router: Router, private render: Renderer2, public alertController: AlertController,
  	private postPvdr: PostProvider,
    public toastCtrl: ToastController,
    private loadingCtrl: LoadingController,
    private usernameService: UsernameService,
    private authService: AuthService,
    private storage: Storage,
    ) {this.user = this.usernameService.getUsernameData() }

  ngOnInit() {
    console.log(this.user);
  }


  update(){

    this.loadingCtrl.create({
      message: 'Please Wait...'
    }).then((overlay) => {
      this.loading = overlay;
      this.loading.present();
    });

    let body = {
      email: this.user,
      aksi: 'updateprofile',
      phone: this.phone,
      name: this.name,
      pass: this.pass
    };

    this.postPvdr.postData(body, 'proses-api.php').subscribe(async data =>{
      var alertpesan = data.msg;
      if(data.success){
        this.storage.set('session_storage', data.result);
        this.usernameService.setUsernameData(data.result.vantage_user);
        this.authService.setAuthData(data.auth_code);
        this.authState.next(true);
       
   
         const toast = await this.toastCtrl.create({
         message: 'Profile Update successful',
         duration: 3000
        });
        console.log(data);
        console.log(data.result);
        toast.present();
this.loading.dismiss();
        this.router.navigate(['dashboard'])

      }else{
        
        console.log(data);
        const toast = await this.toastCtrl.create({
          message: alertpesan,
          duration: 3000
        });
        toast.present();
        
      }
     
    });

  }

}
