import { Component, OnInit, Renderer2 } from '@angular/core';
import { ToastController } from '@ionic/angular';
import { PostProvider } from '../../providers/post-provider';
import { Router } from '@angular/router';
import { LoadingController } from '@ionic/angular';
import { AlertController } from '@ionic/angular';
import { UsernameService } from '../../services/username.service'; 
import { AuthService } from '../../services/auth.service'; 
import { Storage } from '@ionic/storage'; 
import { BehaviorSubject } from 'rxjs';


@Component({
  selector: 'app-changepassword',
  templateUrl: './changepassword.page.html',
  styleUrls: ['./changepassword.page.scss'],
})
export class ChangepasswordPage implements OnInit {

  private loading;

  email: string = "";
  oldpass: string = "";
  newpass: string = "";
  newpassc: string = "";
  address:any;
  city:any;
  state:any;
  zip:any;
  
  data: any;
  user:any;
  rate:any;

  anggota:any;
  krip_email:any;
  krip_user:any;
  user_ip: any;
  balance: any;
  phone_code: any;
  fname:any;
  lname:any;
  currency:any;
  user_state:any;
  user_city:any;
  country:any;
  ex_rate:any; 
  
  constructor(private router: Router, private render: Renderer2, public alertController: AlertController,
  	private postPvdr: PostProvider,
    public toastCtrl: ToastController,
    private loadingCtrl: LoadingController,
    private usernameService: UsernameService,
    private authService: AuthService,
    private storage: Storage,) { }



    ionViewWillEnter(){
      this.storage.get('session_storage').then((res)=>{
        this.anggota = res;
          this.krip_email = this.anggota.krip_email;
          this.krip_user = this.anggota.krip_user;
          this.user_ip = this.anggota.user_ip;
          this.balance = this.anggota.balance;
          this.phone_code = this.anggota.phone_code;
          this.fname = this.anggota.fname;
          this.lname = this.anggota.lname;
          this.currency = this.anggota.currency;
          this.user_state = this.anggota.user_state;
          this.user_city = this.anggota.user_city;
          this.country = this.anggota.country;
          this.ex_rate = this.anggota.ex_rate;
          this.rate = this.anggota.rate
          console.log(res);
          console.log(this.krip_email);
     
  
    });
    
    }


 async updatePass(){

    if(this.oldpass==""){
      const toast = await this.toastCtrl.create({
        message: 'Input old password',
        duration: 3000
      });
      toast.present();
  }else if(this.newpass==""){
      const toast = await this.toastCtrl.create({
        message: 'Input new password',
        duration: 3000
      });
      toast.present();
  }else if(this.newpass != this.newpassc){
    const toast = await this.toastCtrl.create({
      message: 'Password does not match',
      duration: 3000
    });
    toast.present();
}else{

    this.loadingCtrl.create({
      message: 'Please Wait...'
    }).then((overlay) => {
      this.loading = overlay;
      this.loading.present();
    });

    let body = {
      email: this.krip_email,
      aksi: 'updatePasswd',
      oldpass: this.oldpass,
      newpass: this.newpass
    };

    this.postPvdr.postData(body, 'proses-api.php').subscribe(async data =>{
      var alertpesan = data.msg;
      if(data.success){
         const toast = await this.toastCtrl.create({
         message: 'Password Update successful',
         duration: 3000
        });
        console.log(data);
        console.log(data.result);
        toast.present();
this.loading.dismiss();
        this.router.navigate(['profile'])

      }else{
        
        console.log(data);
        const toast = await this.toastCtrl.create({
          message: alertpesan,
          duration: 3000
        });
        toast.present();
        this.loading.dismiss();
        
      }
     
    });

  }

  }


  dashboardPage()
  {
   this.router.navigate(['dashboard'])
  }
   notificationsPage()
  {
  this.router.navigate(['notifications'])
  }
  settingsPage()
  {
	   this.router.navigate(['settings'])
  }
  profilePage()
  {
	  this.router.navigate(['profile'])
  }
  ngOnInit() {
  }

}
