import { Component, OnInit, Renderer2 } from '@angular/core';
import { ToastController } from '@ionic/angular';
import { PostProvider } from '../../providers/post-provider';
import { Router } from '@angular/router';
import { LoadingController } from '@ionic/angular';
import { AlertController } from '@ionic/angular';
import { UsernameService } from '../../services/username.service'; 
import { AuthService } from '../../services/auth.service'; 
import { AuthenticationService } from '../../services/authentication.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {
  private loading;

  email: string = "";
  data: any;

  constructor(private router: Router, private render: Renderer2, public alertController: AlertController,
  	private postPvdr: PostProvider,
    public toastCtrl: ToastController,
    private loadingCtrl: LoadingController,
    private usernameService: UsernameService,
    private authService: AuthService,
    private AuthService: AuthenticationService
    ) { }

  registerPage()
  {
  this.router.navigate(['register'])
  }
  forgotpasswordPage()
  {
  this.router.navigate(['forgotpassword'])
  }
  dashboardPage()
  {
  this.router.navigate(['dashboard'])
  }
  ngOnInit() {
  }

  public onShow(controlToShow) {
    this.render.setStyle(controlToShow, 'visibility', 'visible');
  }
  public onHide(controlToHide) {
    this.render.setStyle(controlToHide, 'visibility', 'hidden');
  }


  async presentAlertConfirm() {
    const alert = await this.alertController.create({
      cssClass: 'my-custom-class',
      header: '',
      message: 'Confirm <strong>' + this.email +' </strong> is your email before proceeding!',
      buttons: [
        {
          text: 'Yes it is',
          role: 'Yes it is',
          cssClass: 'secondary',
          handler: async (blah) => {




            if(this.email==""){
              const toast = await this.toastCtrl.create({
                message: 'Email is required',
                duration: 3000
              });
              toast.present();
          }
         else{
      
          this.loadingCtrl.create({
            message: 'Please Wait...'
          }).then((overlay) => {
            this.loading = overlay;
            this.loading.present();
          });

            let body = {
              email: this.email,
              aksi: 'register'
            };
      
            this.postPvdr.postData(body, 'proses-api.php').subscribe(async data =>{
              var alertpesan = data.msg;
              if(data.success){
                this.usernameService.setUsernameData(data.krip_email);
                this.authService.setAuthData(data.auth_code);
                
           
                 const toast = await this.toastCtrl.create({
                 message: 'Registered successful',
                 duration: 3000
                });
                console.log(data);
                console.log(data.krip_email);
                console.log(data.auth_code);
                toast.present();
                this.loading.dismiss();
                this.router.navigate(['email-verification'])

              }else{
                
                console.log(data);
                const toast = await this.toastCtrl.create({
                  message: alertpesan,
                  duration: 3000
                });
                this.usernameService.setUsernameData(this.email);
                console.log(this.email);
                this.loading.dismiss();
                toast.present();
                this.router.navigate(['password'])
                
              }
             
            });
      
          }


            
          }
        }, {
          text: 'Change ',
          handler: () => {
            console.log('Confirm Okay');
          }
        }
      ]
    });

    await alert.present();
  }

  clearPage()
  {
	  this.AuthService.clear();
  }

}
