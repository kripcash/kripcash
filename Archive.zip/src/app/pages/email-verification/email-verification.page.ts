import { Component, OnInit } from '@angular/core';
import {LoadingController, ToastController} from "@ionic/angular"
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service'; 
import { UsernameService } from '../../services/username.service'; 

@Component({
  selector: 'app-email-verification',
  templateUrl: './email-verification.page.html',
  styleUrls: ['./email-verification.page.scss'],
})
export class EmailVerificationPage implements OnInit {

  auth: any;
  use:any;

  otp: string = "";
  constructor(private router: Router, public loadingCtrl: LoadingController, public toastCtrl: ToastController,
    private authService: AuthService, private usernameService: UsernameService ) { this.auth = this.authService.getAuthData(), this.use = this.usernameService.getUsernameData()}


  ngOnInit() {
  }

  async presentLoading() {
    const loading = await this.loadingCtrl.create({
      message: 'Verifying Code...',
      spinner: "circular"
    });
    await loading.present();
  }

  async presentToast(message, color){
    const toast =await this.toastCtrl.create({
      message: message,
      color: color,
      duration: 1000,
      position: "middle",
    });
    toast.present();
  }

  registerPage(){
    this.router.navigate(['login'])
  }

  checkOTP() {
    this.presentLoading();
    setTimeout(() => {
      this.loadingCtrl.dismiss();

      if (this.otp == this.auth) {
        this.usernameService.setUsernameData(this.use);
        this.presentToast("Code Verified", "success");
        this.router.navigate(['profile-update'])
      }
      else {
        this.presentToast("Invalid Code", "danger");
      }
    }, 2000)
  }

}
