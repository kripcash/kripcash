import { Component, OnInit, Renderer2, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { ModalController } from '@ionic/angular';
import { ToastController } from '@ionic/angular';
import { PostProvider } from '../../providers/post-provider';
import { LoadingController } from '@ionic/angular';
import { AlertController } from '@ionic/angular';
import { AuthService } from '../../services/auth.service'; 
import { BankaccountService } from '../../services/bankaccount.service'; 
import { Storage } from '@ionic/storage'; 

@Component({
  selector: 'app-add-bank',
  templateUrl: './add-bank.page.html',
  styleUrls: ['./add-bank.page.scss'],
})
export class AddBankPage implements OnInit {

  email: string = "";
  address:any;
  city:any;
  state:any;
  zip:any;
  
  data: any;
  user:any;
  rate:any; 

  anggota:any;
  krip_email:any;
  krip_user:any;
  user_ip: any;
  balance: any;
  phone_code: any;
  fullname:any;
  currency:any;
  user_state:any;
  user_city:any;
  country:any;
  ex_rate:any; 
  sold_coin:any;
  bought_coin:any;
  bank_name:any;
  bank_acc_name:any;
  bank_acc_num:any;

  b_acc_acc_name:any;
  b_acc_acc_num:any;
  b_acc_id:any;
  b_acc_bank_name:any;

  bname:any;
  baccnumber:any;
  baccname:any;
 

  constructor(private modal: ModalController, private router: Router, private render: Renderer2, public alertController: AlertController,
   private postPvdr: PostProvider,
   public toastCtrl: ToastController,
   private loadingCtrl: LoadingController,
   private bankService: BankaccountService,
   private authService: AuthService,
   private storage: Storage,) { }

  closeModal(){
    this.modal.dismiss();
  }


  ionViewWillEnter(){
    this.storage.get('session_storage').then((res)=>{
      this.anggota = res;
        this.krip_email = this.anggota.krip_email;
        this.krip_user = this.anggota.krip_user;
        this.user_ip = this.anggota.user_ip;
        this.balance = this.anggota.balance;
        this.phone_code = this.anggota.phone_code;
        this.fullname = this.anggota.fullname;
        this.currency = this.anggota.currency;
        this.user_state = this.anggota.user_state;
        this.user_city = this.anggota.user_city;
        this.country = this.anggota.country;
        this.ex_rate = this.anggota.ex_rate;
        this.rate = this.anggota.rate,
        this.sold_coin = this.anggota.sold_coin,
        this.bought_coin = this.anggota.bought_coin

        console.log(res);
        console.log(this.krip_email);
   

    let body = {
      kripemail : this.anggota.krip_email,
      aksi: 'bankacc'
    };

    this.postPvdr.postData(body, 'proses-api.php').subscribe(async data =>{
      var alertpesan = data.msg;
      if(data.success){
        this.bankService.setBankData(data.result);
        this.b_acc_bank_name = data.result.b_acc_bank_name;
        this.b_acc_acc_num = data.result.b_acc_acc_num;
        this.b_acc_acc_name = data.result.b_acc_acc_name;
        this.b_acc_id = data.result.id;

        console.log(data.result);
        
      }else{
        const toast = await this.toastCtrl.create({
          message: 'Input Bank Details To Receive Funds',
          duration: 3000
        });
        toast.present();
        console.log(data);
      }
    });

  });
  
  }



  async updateBank(){

    const loading = await this.loadingCtrl.create({
      message: 'Updating...',
      spinner: "circular"
    });
    await loading.present();

    let body = {
      kripemail : this.anggota.krip_email,
      bname: this.bname,
      baccnumber: this.baccnumber,
      baccname: this.baccname,
      aksi: 'bankupdate'
    };

    this.postPvdr.postData(body, 'proses-api.php').subscribe(async data =>{
      var alertpesan = data.msg;
      if(data.success){
        this.modal.dismiss();
        console.log(data.result);
        this.router.navigate(['dashboard']); 

        const toast = await this.toastCtrl.create({
          message: 'Bank account updated successfully',
          duration: 3000
        });
        this.loadingCtrl.dismiss();
        toast.present();
        
      }else{
        const toast = await this.toastCtrl.create({
          message: 'No Bank Details Added Yet',
          duration: 3000
        });
        toast.present();
        console.log(data);
      }
    });

  }

  ngOnInit() {
  }

}
