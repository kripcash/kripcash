import { Component, OnInit, Renderer2, ViewChild} from '@angular/core';
import { Router } from '@angular/router';
import { IonContent, ModalController } from '@ionic/angular';
import { ToastController } from '@ionic/angular';
import { PostProvider } from '../../providers/post-provider';
import { LoadingController } from '@ionic/angular';
import { AlertController } from '@ionic/angular';
import { TicketService } from '../../services/ticket.service'; 
import { Storage } from '@ionic/storage'; 


@Component({
  selector: 'app-chat',
  templateUrl: './chat.page.html',
  styleUrls: ['./chat.page.scss'],
})
export class ChatPage implements OnInit {

  [x: string]: any;

  email: string = "";
   address:any;
   city:any;
   state:any;
   zip:any;
   
   data: any;
   user:any;
   rate:any; 
 
   anggota:any;
   krip_email:any;
   krip_user:any;
   user_ip: any;
   balance: any;
   phone_code: any;
   fullname:any;
   currency:any;
   user_state:any;
   user_city:any;
   country:any;
   ex_rate:any; 
   sold_coin:any;
   bought_coin:any;
   ticketID:any;

   tmsg: any;
   ttype:any;
   tid:any;

  messages: any=[];

  ticket: any;

  private contactInfo: any = {
    name: 'JOHN DOE',
    status: 'ONLINE'
  }

  public showOptions: boolean = false;

  newMsg = '';

  @ViewChild(IonContent, {static: true}) content: IonContent;

 
  constructor(private modalController: ModalController, private router: Router, private render: Renderer2, public alertController: AlertController,
  	private postPvdr: PostProvider,
    public toastCtrl: ToastController,
    private ticketService: TicketService,
    private loadingCtrl: LoadingController,
    private storage: Storage) { 
      this.ticketidd = this.ticketService.getTicketData()
    }

    async ionViewWillEnter(){

      const loading = await this.loadingCtrl.create({
        message: 'Please Wait...',
        spinner: "circular",
        duration: 3000
      });
      await loading.present();

      this.storage.get('session_storage').then((res)=>{
        this.anggota = res;
          this.krip_email = this.anggota.krip_email;
          this.krip_user = this.anggota.krip_user;
          this.user_ip = this.anggota.user_ip;
          this.balance = this.anggota.balance;
          this.phone_code = this.anggota.phone_code;
          this.fullname = this.anggota.fullname;
          this.currency = this.anggota.currency;
          this.user_state = this.anggota.user_state;
          this.user_city = this.anggota.user_city;
          this.country = this.anggota.country;
          this.ex_rate = this.anggota.ex_rate;
          this.rate = this.anggota.rate,
          this.sold_coin = this.anggota.sold_coin,
          this.bought_coin = this.anggota.bought_coin

          console.log(res);
          console.log(this.krip_email);
     
  
          let body = {
            kripUser : this.anggota.krip_email,
            ticketId : this.ticketidd,
            aksi: 'getTicket'
          };
      
          this.postPvdr.postData(body, 'proses-api.php').subscribe(async data =>{
            var alertpesan = data.msg;
            if(data.success){
              this.tickets = data.result,
              this.tuser = this.tickets.ticketuser,
              this.ttype = data.result.tickettype,
              this.tmsg = data.result.ticketmsg,
              this.tid = data.result.ticketid,
              this.tstatus = data.result.status,
              this.tdate = data.result.date
              
      
              console.log(data);
              console.log(this.ticket);
              
            }else{
              
              console.log(data);
            }

      });

      let bod = {
        kripUser : this.anggota.krip_email,
        tickId : this.ticketidd,
        aksi: 'getMessage'
      };
  
      this.postPvdr.postData(bod, 'proses-api.php').subscribe(async data =>{
        var alertpesan = data.msg;
        if(data.success){
          this.messages = data.result,
          
          
  
          console.log(data);
          console.log(this.messages);
          
        }else{
          
          console.log(data);
        }

  });
  
    });
    
    }


  ngOnInit() {
    this.content.scrollToBottom(200);
  }

  async doRefresh(){
    const toast = await this.toastCtrl.create({
      message: 'Refreshing messages...',
      duration:1000
    });
    toast.present();


    let bod = {
      kripUser : this.anggota.krip_email,
      tickId : this.ticketidd,
      aksi: 'getMessage'
    };

    this.postPvdr.postData(bod, 'proses-api.php').subscribe(async data =>{
      var alertpesan = data.msg;
      if(data.success){
        this.messages = data.result,
        
        

        console.log(data);
        console.log(this.messages);
        
      }else{
        
        console.log(data);
      }

});

  }

 async sendMsg(){
    if(this.newMsg==""){
      const toast = await this.toastCtrl.create({
        message: 'Please input message',
        duration:1000
      });
      toast.present();
  }else{

    let body = {
      kripUser : this.krip_email,
      tickId : this.ticketidd,
      text: this.newMsg,
      type: 'send',
      aksi: 'sendMsg'
    };

    this.postPvdr.postData(body, 'proses-api.php').subscribe(async data =>{
      var alertpesan = data.msg;
      if(data.success){
        this.messag = data.result,
        
        

        console.log(data);
        console.log(this.messag);
        
      }else{
        
        console.log(data);
      }

});

    this.messages.push({
      text: this.newMsg,
      type: 'send',
      created: 'just now'
      // created: new Date().getTime()
    });

    this.newMsg = '';

    setTimeout(() =>{
      this.content.scrollToBottom(200);
    });
  }
    
  }

  goBack(){
    this.router.navigate(['ticket'])
  }

  showOptionsToggle(value?: boolean) {
    if (value !== undefined) {
      this.showOptions = value;
      return;
    }
    this.showOptions = !this.showOptions;
  }

}
