import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ReceiveBtcPageRoutingModule } from './receive-btc-routing.module';

import { ReceiveBtcPage } from './receive-btc.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ReceiveBtcPageRoutingModule
  ],
  declarations: [ReceiveBtcPage]
})
export class ReceiveBtcPageModule {}
