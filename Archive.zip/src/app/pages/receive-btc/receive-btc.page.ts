import { Component, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';
import { CreateTicketPage } from '../create-ticket/create-ticket.page'; 

@Component({
  selector: 'app-receive-btc',
  templateUrl: './receive-btc.page.html',
  styleUrls: ['./receive-btc.page.scss'],
})
export class ReceiveBtcPage implements OnInit {

  constructor(private modalController: ModalController) { }

  ngOnInit() {
  }

 async createTicket(){
    this.modalController.dismiss();

    const modal = await this.modalController.create({
      component: CreateTicketPage
    });
    return await modal.present();
  }

  closeModal(){
    this.modalController.dismiss();
  }

} 
