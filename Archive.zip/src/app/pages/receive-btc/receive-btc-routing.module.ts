import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ReceiveBtcPage } from './receive-btc.page';

const routes: Routes = [
  {
    path: '',
    component: ReceiveBtcPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ReceiveBtcPageRoutingModule {}
