import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../services/authentication.service';
import { AuthService } from '../services/auth.service'; 
import { Storage } from '@ionic/storage';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
  log: any;

  constructor(private router: Router, 
    private storage: Storage, private authenticationService: AuthenticationService, private authService: AuthService) {
    this.log = this.authService.getAuthData()
  }


    ngOnInit() {

      this.storage.get('session_storage').then((response) => {
        if (response) {
          this.router.navigate(['dashboard']);
        }else if(this.log){
          setTimeout(() => {
                this.router.navigate(['walkthrough'])
              }
              , 5000);
        }else {
          setTimeout(() => {
            this.router.navigate(['walkthrough'])
          }
          , 5000);
        }
      });

       
	  }

    closeModal(){
      this.router.navigate(['walkthrough'])
    }

}
