import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouteReuseStrategy } from '@angular/router';
import { IonicModule, IonicRouteStrategy } from '@ionic/angular';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { Clipboard } from '@ionic-native/clipboard/ngx';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { Camera } from '@ionic-native/camera/ngx';
import { PostProvider } from './providers/post-provider';
import { HttpClientModule} from '@angular/common/http';
import { BarcodeScanner } from '@ionic-native/barcode-scanner/ngx';
import { SendBtcPageModule } from './pages/send-btc/send-btc.module';
import { AddBankPageModule } from './pages/add-bank/add-bank.module';
import { CreateTicketPageModule } from './pages/create-ticket/create-ticket.module';
import { ReceiveBtcPageModule } from './pages/receive-btc/receive-btc.module';
import { IonicStorageModule } from '@ionic/storage';

import { AuthGuardService } from './services/auth-guard.service';
import { AuthenticationService } from './services/authentication.service';



@NgModule({
  declarations: [AppComponent],
  entryComponents: [],
  imports: [BrowserModule,HttpClientModule, IonicModule.forRoot(), AppRoutingModule, IonicStorageModule.forRoot(),SendBtcPageModule,ReceiveBtcPageModule,AddBankPageModule,CreateTicketPageModule],
  providers: [
    Camera,
    Clipboard,
    StatusBar,
	BarcodeScanner,
  HttpClientModule,
    SplashScreen,
    PostProvider,
    AuthGuardService,
    AuthenticationService,
    IonicStorageModule,
    { provide: RouteReuseStrategy, useClass: IonicRouteStrategy }
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}
