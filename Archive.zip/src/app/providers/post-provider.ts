import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable()
export class PostProvider {
	server: string = "https://vantagecryptos.co.uk/krip/"; // default
	
	constructor(public http : HttpClient) {

	}

	postData(body, file) {
		const headers = new HttpHeaders({
		  'Content-Type':"application/json; charset=UTF-8"
		})
	  
		return this.http.post<any>(this.server + file, body, {headers})
	  }
	  
}