import { Injectable } from '@angular/core';
import { isNullOrUndefined } from 'util';

@Injectable({
  providedIn: 'root' 
})
export class AuthService {

  authData: any;

  constructor() { }

  setAuthData(SuccessObj){
 this.authData = SuccessObj
  }

  getAuthData(){
    if (isNullOrUndefined(this.authData))
    return 0
 return this.authData
  }
} 