import { Injectable } from '@angular/core';
import { isNullOrUndefined } from 'util';

@Injectable({
  providedIn: 'root'
})
export class UsernameService {
  usernameData: any;

  constructor() { }

  setUsernameData(SuccessObj){
 this.usernameData = SuccessObj
  }

  getUsernameData(){
    if (isNullOrUndefined(this.usernameData))
    return 0
 return this.usernameData
  }
}
