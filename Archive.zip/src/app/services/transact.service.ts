import { Injectable } from '@angular/core';
import { isNullOrUndefined } from 'util';

@Injectable({
  providedIn: 'root'
})
export class TransactService {

  transactData: any; 

  constructor() { }

  setTransactData(SuccessObj){
 this.transactData = SuccessObj
  }

  getTransactData(){
    if (isNullOrUndefined(this.transactData))
    return 0
 return this.transactData
  }
}