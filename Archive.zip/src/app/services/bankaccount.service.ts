import { Injectable } from '@angular/core';
import { isNullOrUndefined } from 'util';

@Injectable({
  providedIn: 'root'
})
export class BankaccountService {

  bankData: any;

  constructor() { }

  setBankData(SuccessObj){
 this.bankData = SuccessObj
  }

  getBankData(){
    if (isNullOrUndefined(this.bankData))
    return 0
 return this.bankData
  }
}