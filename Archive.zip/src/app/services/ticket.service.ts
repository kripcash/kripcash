import { Injectable } from '@angular/core';
import { isNullOrUndefined } from 'util';

@Injectable({
  providedIn: 'root'
})
export class TicketService {

  ticketData: any; 

  constructor() { }

  setTicketData(SuccessObj){
 this.ticketData = SuccessObj
  }

  getTicketData(){
    if (isNullOrUndefined(this.ticketData))
    return 0
 return this.ticketData
  }
}